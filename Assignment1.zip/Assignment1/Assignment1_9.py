#Write a program which display first 10 even numbers on screen. 

def Even():
    for i in range(0,11,2):
        print(i);

def main():
    Even();

if __name__ == "__main__":
    main();