#Write a function to display "Hello from fun " on console

def fun():
    print("Hello from fun");

def main():
    fun();


if __name__ == "__main__":
    main();