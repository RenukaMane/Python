#.Write a program which display 5 times Marvellous on screen.

def Display():
    for i in range(5):
        print("Marvellous");

def main():
    Display();

if __name__ == "__main__":
    main();