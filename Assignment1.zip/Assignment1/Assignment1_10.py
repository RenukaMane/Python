#Write a program which accept name from user and display length of its name. 

def StrLen():
    print("Enter a string");
    str = input();
    print(len(str));

def main():
    StrLen();

if __name__ == "__main__":
    main();